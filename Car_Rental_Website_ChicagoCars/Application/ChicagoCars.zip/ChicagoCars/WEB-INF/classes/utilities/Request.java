package utilities;

import java.util.*;

public class Request{
    public static List<String> pZipCodes = new ArrayList<String>();
    public static List<String> dZipCodes = new ArrayList<String>();
    public static String pickdate="";
    public static String picktime="";
    public static String droptime="";
    public static String dropdate="";
}